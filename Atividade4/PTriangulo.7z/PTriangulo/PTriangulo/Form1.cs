﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void txtA_Validating(object sender, CancelEventArgs e)
        {
            double ValA;
            errorProvider1.SetError(txtA, "");

            if ((!double.TryParse(txtA.Text, out ValA)) || (ValA <=0))
            {
                MessageBox.Show("Valor inválido!");
                errorProvider1.SetError(txtA, "Valor inválido");
            }
        }

        private void txtB_Validating(object sender, CancelEventArgs e)
        {
            double ValB;
            errorProvider2.SetError(txtB, "");

            if ((!double.TryParse(txtB.Text, out ValB)) || (ValB <= 0))
            {
                MessageBox.Show("Valor inválido!");
                errorProvider2.SetError(txtB, "Valor inválido");
            }
        }

        private void txtC_Validating(object sender, CancelEventArgs e)
        {
            double ValC;
            errorProvider3.SetError(txtC, "");

            if ((!double.TryParse(txtC.Text, out ValC)) || (ValC <= 0))
            {
                MessageBox.Show("Valor inválido!");
                errorProvider3.SetError(txtC, "Valor inválido");
            }
        }

        private void butVerificar_Click(object sender, EventArgs e)
        {
            double ValA, ValB, ValC;
            if (Double.TryParse(txtA.Text, out ValA) &&
                Double.TryParse(txtB.Text, out ValB) &&
                Double.TryParse(txtC.Text, out ValC))
            {

                if ((Math.Abs(ValB - ValC) < ValA && ValA < (ValB + ValC)) &&
                   (Math.Abs(ValA - ValC) < ValB && ValB < (ValA + ValC)) &&
                   (Math.Abs(ValA - ValB) < ValC && ValC < (ValA + ValB)))
                {
                    if ((ValA == ValB) && (ValB == ValC) && (ValA == ValC))
                        txtResultado.Text = "Triângulo equilatero";

                    else if ((ValA == ValB) || (ValB == ValC) || (ValA == ValC))
                        txtResultado.Text = "Triângulo isósceles";

                    else if ((ValA != ValB) && (ValB != ValC) && (ValA != ValC))
                        txtResultado.Text = "Triângulo escaleno";
                }
                else
                    txtResultado.Text = "Não é um triângulo";
            }
        }

        private void butLimpar_Click(object sender, EventArgs e)
        {
            txtA.Clear();
            txtB.Clear();
            txtC.Clear();
            txtResultado.Clear();
        }

        private void butSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
