﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PNotas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnVerificar_Click(object sender, EventArgs e)
        {
            char[,] notas = new char[4, 10];
            char[] gabarito = { 'A', 'D', 'C', 'E', 'B', 'C', 'D', 'A', 'B', 'A'};
            string auxiliar = "";


            for (int aluno = 0; aluno < 4; aluno++)
            {
                for (int resp = 0; resp < 10; resp++)
                {
                    auxiliar = Interaction.InputBox($"digite a {resp+1}º resposta do {aluno+1}º aluno");

                    if (auxiliar.Length == 0)
                    {
                        return;
                    }

                    if (char.TryParse(auxiliar, out notas[aluno,resp]) && (notas[aluno, resp] == 'A' || notas[aluno, resp] == 'B' || notas[aluno, resp] == 'C' || notas[aluno, resp] == 'D' || notas[aluno, resp] == 'E'))
                    {
                        if (notas[aluno, resp] == gabarito[resp])
                        {
                            lbox1.Items.Add($"O aluno {aluno+1} acertou a questão {resp+1} era {gabarito[resp]}, escolheu {notas[aluno,resp]}");
                        }
                        else
                            lbox1.Items.Add($"O aluno {aluno + 1} errou a questão {resp + 1} era {gabarito[resp]}, escolheu {notas[aluno, resp]}");
                    }
                    else
                    {
                        MessageBox.Show("A resposta precisa ser A, B, C, D ou E");
                        resp--;
                    }
                }
            }

        }
    }
}
