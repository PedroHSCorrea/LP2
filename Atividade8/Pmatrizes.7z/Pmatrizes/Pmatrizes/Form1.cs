﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace Pmatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnEx1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";
            string saida = "";

            for (var i = 0; i < 20; i++)
            {
                auxiliar = Interaction.InputBox($"Digite um nº para a posição: {i}");
                if(!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número inválido");
                    i--;

                    if (auxiliar.Length == 0)
                    {
                        return;
                    }
                }
                else
                {
                    saida = vetor[i] + "\n" + saida;
                }
            }
            MessageBox.Show(saida);

            Array.Reverse(vetor);
            auxiliar = "";
            foreach (int i in vetor)
                auxiliar += i + "\n";
            MessageBox.Show(auxiliar);
        }

        private void BtnEx2_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            string auxiliar = "";
            string saida = "";
            double media = 0;

            for (int aluno = 0; aluno < 20; aluno++)
            {
                media = 0;
                for (int nota = 0; nota < 3; nota++)
                {
                    auxiliar = Interaction.InputBox($"Digite a {nota + 1}º nota do {aluno + 1}º aluno");

                    if(auxiliar.Length == 0)
                    {
                        return;
                    }

                    else if (!double.TryParse(auxiliar, out notas[aluno, nota]) || (notas[aluno, nota] < 0) || (notas[aluno, nota] > 10))
                    {
                        MessageBox.Show("Nota inválida");
                        nota--;
                    }
                    else
                    {
                        media += notas[aluno, nota];
                    }
                }
                media = media / 3;
                saida = saida + "\n" + $"media do {aluno + 1}º aluno: " + media.ToString("N2");
            }
            MessageBox.Show(saida);
        }

        private void btnEx3_Click(object sender, EventArgs e)
        {
            string[] Alunos = {"Viviane", "André", "Hélio", "Denise", "Junior", "Leonardo", "Jose", "Nelma", "Tobby"};
            Int32 I, Total = 0;
            Int32 N = Alunos.Length;
            for (I = 0; I < N - 1; I++)
            {
                Total += Alunos[I].Length;
            }
            MessageBox.Show(Total.ToString());
        }

        private void btnEx4_Click(object sender, EventArgs e)
        {
            string auxiliar = "";
            ArrayList lista = new ArrayList();
            lista.Add("Ana");
            lista.Add("André");
            lista.Add("Débora");
            lista.Add("Fátima");
            lista.Add("João");
            lista.Add("Janete");
            lista.Add("Otávio");
            lista.Add("Marcelo");
            lista.Add("Pedro");
            lista.Add("Thais");

            lista.Remove("Otávio");

            foreach(object c in lista)
            {
                auxiliar = auxiliar + "\n" + c;
            }

            MessageBox.Show(auxiliar);

        }

        private void btnEx5_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmEx5>().Count() > 0)
            {
                MessageBox.Show("Form já existe");
                Application.OpenForms["frmEx5"].Activate();
            }
            else
            {
                frmEx5 Frm5 = new frmEx5();
                Frm5.Show();
            }
        }
    }
}
