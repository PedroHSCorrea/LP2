﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pmatrizes
{
    public partial class frmEx5 : Form
    {
        public frmEx5()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[4];
            string auxiliar = "";
            int[] numCaracteres = new int[4];
            int espaços = 0;

            for (int i = 0; i < 4; i++)
            {
                auxiliar = Interaction.InputBox($"digite o nome");
                nomes[i] = auxiliar;
                foreach (char c in auxiliar)
                {
                    if (char.IsWhiteSpace(c))
                    {
                        espaços++;
                    }
                }
                numCaracteres[i] = auxiliar.Length - espaços;
                espaços = 0;

                auxiliar ="\no nome:" + auxiliar + " tem " + numCaracteres[i] + " caracteres";
                lbox1.Items.Add(auxiliar);
            }

        }
    }
}
